#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

xcodebuild \
  -project ThreeOneOSFive.xcodeproj \
  -target 3105 \
  -configuration Release \
  -sdk iphoneos \
  -derivedDataPath "$PWD/.derivedData" \
  build \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGNING_REQUIRED=NO \
  CODE_SIGN_IDENTITY=""

APP_PATH="$PWD/.derivedData/Build/Products/Release-iphoneos/3105.app"
test -d "$APP_PATH"
mkdir -p "$PWD/build/Payload"
rm -rf "$PWD/build/Payload/3105.app"
cp -R "$APP_PATH" "$PWD/build/Payload/"
(cd "$PWD/build" && zip -qr 3105-iOS27-unsigned.ipa Payload)
printf 'Created: %s\n' "$PWD/build/3105-iOS27-unsigned.ipa"
