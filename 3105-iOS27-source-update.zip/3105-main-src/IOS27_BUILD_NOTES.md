# iOS 27 build notes

- Xcode deployment target is set to **iOS 27.0**. iOS 27.0.1 devices use the same 27.0 SDK deployment setting; patch-level deployment targets are not supported by Xcode build settings.
- The original exploit, kernel, sandbox, and anti-detection source files are retained byte-for-byte from the supplied archive. They have not been updated, enabled, or validated for iOS 27.0.1.
- Changing `IPHONEOS_DEPLOYMENT_TARGET` only sets the minimum OS version. It does not establish runtime compatibility for privileged operations, kernel offsets, exploit chains, or private APIs.
- Build with an Xcode release whose installed iPhoneOS SDK supports iOS 27. The unsigned IPA must be signed separately.

Run `./build-unsigned.sh` on macOS with Xcode command-line tools installed.
