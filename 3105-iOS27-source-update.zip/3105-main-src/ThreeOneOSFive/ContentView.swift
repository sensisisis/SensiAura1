import SwiftUI
import UIKit
import Foundation
import CryptoKit
import Darwin

struct ContentView: View {
    @Environment(\.appLanguage) private var language
    @Environment(\.horizontalSizeClass) private var horizontalSizeClass
    @Environment(\.scenePhase) private var scenePhase
    @EnvironmentObject private var patchDraftCoordinator: PatchDraftCoordinator
    @EnvironmentObject private var patchStore: PatchProjectStore
    @EnvironmentObject private var repositoryStore: PackageRepositoryStore
    @AppStorage(FeatureVisibility.developerModeStorageKey)
    private var developerModeEnabled = false
    @State private var tabNavigation: AppTabNavigationState
    @StateObject private var keySession = SupabaseKeySession()
    @State private var showSettings = false
    @State private var showLogs = false

    init() {
#if targetEnvironment(simulator)
        let arguments = ProcessInfo.processInfo.arguments
        let initialTab: Int
        if arguments.contains("--simulate-installed-tab")
                    || arguments.contains("--simulate-patch-tab")
                    || arguments.contains("--simulate-wallpaper-tab") {
            initialTab = AppSection.installed.rawValue
        } else {
            initialTab = AppSection.home.rawValue
        }
        _tabNavigation = State(initialValue: AppTabNavigationState(selectedTab: initialTab))
        _showSettings = State(
            initialValue: arguments.contains("--simulate-settings")
        )
#else
        _tabNavigation = State(initialValue: AppTabNavigationState(selectedTab: AppSection.installed.rawValue))
#endif
    }

    var body: some View {
        Group {
            if keySession.isAuthorized {
                if keySession.selectedMode != nil {
                    if horizontalSizeClass == .regular {
                        regularLayout
                    } else {
                        compactLayout
                    }
                } else {
                    FirebaseAuraModeSelectionView { mode in
                        keySession.selectMode(mode)
                    }
                }
            } else {
                FirebaseKeyActivationView(sessionNotice: keySession.notice) { key in
                    await keySession.activate(key)
                }
            }
        }
        .tint(AppTheme.accent)
        .imageScale(.small)
        .onChange(of: patchDraftCoordinator.request?.id) { requestID in
            if requestID != nil { tabNavigation.select(AppSection.installed.rawValue) }
        }
        .onChange(of: patchDraftCoordinator.importRequest?.id) { requestID in
            if requestID != nil { tabNavigation.select(AppSection.installed.rawValue) }
        }
        .onChange(of: developerModeEnabled) { _ in
            tabNavigation.reconcileSelection(with: featureVisibility)
        }
        .onChange(of: keySession.isAuthorized) { authorized in
            if !authorized { showSettings = false }
        }
        .onAppear {
            tabNavigation.reconcileSelection(with: featureVisibility)
        }
        .task(id: scenePhase) {
            await keySession.runForegroundSession(for: scenePhase)
        }
        .sheet(isPresented: $showSettings) { SettingsView() }
        .sheet(isPresented: $showLogs) { LogView() }
        .patchStorePresentation(patchStore)
        .repositoryStorePresentation(repositoryStore, patchStore: patchStore)
    }

    private var compactLayout: some View {
        TabView(selection: tabSelection) {
            ForEach(featureVisibility.visibleSections) { section in
                sectionContent(section)
                    .tabItem {
                        CompactTabLabel(
                            title: language.text(section.titleKey),
                            systemImage: section.systemImage
                        )
                    }
                    .tag(section.rawValue)
            }
        }
        .tint(Color(red: 0.95, green: 0.12, blue: 0.16))
    }

    private var regularLayout: some View {
        NavigationSplitView {
            List {
                ForEach(featureVisibility.visibleSections) { section in
                    Button {
                        withAnimation(.easeInOut(duration: 0.18)) {
                            tabNavigation.select(section.rawValue)
                        }
                    } label: {
                        Label(language.text(section.titleKey), systemImage: section.systemImage)
                            .fontWeight(section.rawValue == tabNavigation.selectedTab ? .semibold : .regular)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    .listRowBackground(
                        section.rawValue == tabNavigation.selectedTab
                            ? AppTheme.accent.opacity(0.14)
                            : Color.clear
                    )
                    .accessibilityAddTraits(
                        section.rawValue == tabNavigation.selectedTab ? .isSelected : []
                    )
                }
            }
            .navigationTitle("Fax Aura")
            .navigationSplitViewColumnWidth(min: 210, ideal: 240, max: 300)
        } detail: {
            sectionContent(selectedVisibleSection)
                .id(selectedVisibleSection.rawValue)
        }
        .navigationSplitViewStyle(.balanced)
    }

    @ViewBuilder
    private func sectionContent(_ section: AppSection) -> some View {
        switch section {
        case .home:
            RepositoryHomeView(
                onOpenSettings: openSettings,
                onOpenLogs: openLogs
            )
        case .installed:
            PatchProjectsView(
                onOpenSettings: openSettings,
                onOpenLogs: openLogs
            )
        }
    }

    private var tabSelection: Binding<Int> {
        Binding(
            get: { tabNavigation.selectedTab },
            set: { tabNavigation.select($0) }
        )
    }

    private var filesTabSession: Binding<FilesTabSession> {
        Binding(
            get: { tabNavigation.filesTabs },
            set: { tabNavigation.setFilesTabs($0) }
        )
    }

    private var featureVisibility: FeatureVisibility {
        FeatureVisibility(developerModeEnabled: developerModeActive)
    }

    private var developerModeActive: Bool {
#if targetEnvironment(simulator)
        developerModeEnabled
            || ProcessInfo.processInfo.arguments.contains("--simulate-developer-mode")
            || ProcessInfo.processInfo.arguments.contains("--simulate-files-tab")
#else
        developerModeEnabled
#endif
    }

    private var selectedVisibleSection: AppSection {
        let selected = AppSection(rawValue: tabNavigation.selectedTab)
        return selected.flatMap {
            featureVisibility.isVisible($0) ? $0 : nil
        } ?? .installed
    }

    private func openSettings() {
        showSettings = true
    }

    private func openLogs() {
        showLogs = true
    }
}

private struct CompactTabLabel: View {
    let title: String
    let systemImage: String

    @ViewBuilder
    var body: some View {
        if let image = UIImage(
            systemName: systemImage,
            withConfiguration: UIImage.SymbolConfiguration(pointSize: 17, weight: .medium)
        )?.withRenderingMode(.alwaysTemplate) {
            Image(uiImage: image)
        } else {
            Image(systemName: systemImage)
                .font(.system(size: 17, weight: .medium))
        }
        Text(title)
    }
}

private extension AppSection {
    var titleKey: String {
        switch self {
        case .home: return "tab.home"
        case .installed: return "tab.installed"
        }
    }

    var systemImage: String {
        switch self {
        case .home: return "house.fill"
        case .installed: return "tray.and.arrow.down.fill"
        }
    }
}


private enum FaxAuraMode: String {
    case normal = "normal"

    var title: String { "Normal" }
    var subtitle: String { "Stable Free Fire profile" }
    var icon: String { "flame.fill" }
}

private enum FirebaseKeyValidationResult {
    case success(String)
    case failure(String)
}

private enum SupabaseValidationOutcome {
    case active(SupabaseAuraValidationResponse)
    case rejected(SupabaseAuraValidationResponse)
    case transportFailure(String)
}

@MainActor
private final class SupabaseKeySession: ObservableObject {
    @Published private(set) var isAuthorized = false
    @Published private(set) var selectedMode: FaxAuraMode?
    @Published private(set) var notice: String?

    private let savedKeyStorage = "fax-aura.supabase.active-key"
    private let legacyKeyStorage = "fax-aura.firebase.active-key"
    private let sessionVersionStorage = "fax-aura.supabase.session-version"
    private let fallbackDeviceIDStorage = "fax-aura.supabase.fallback-device-id"
    private let modeStorage = "fax-aura.selected-mode"
    private let expirationStorage = "fax-aura.supabase.expires-at"
    private let supabaseURL = "https://skarpahwcwkqdfxgtvlp.supabase.co"
    private let anonKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNrYXJwYWh3Y3drcWRmeGd0dmxwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTIwMjc3NTYsImV4cCI6MjEwNzYwMzc1Nn0.PUh5QIs_W61En2PdyML31uzMFG_8NvCAHeRp1qYBzFw"
    private var validationGeneration = 0
    private var explicitActivationInFlight = false

    func runForegroundSession(for phase: ScenePhase) async {
        guard phase == .active else { return }

        await restore()
        var nextHeartbeat = Date().addingTimeInterval(15)

        while !Task.isCancelled {
            do {
                try await Task.sleep(nanoseconds: 1_000_000_000)
            } catch {
                return
            }
            guard !Task.isCancelled else { return }

            if isAuthorized, localExpirationHasPassed {
                deauthorize()
                notice = "Checking session status..."
                await heartbeat()
                nextHeartbeat = Date().addingTimeInterval(15)
            }

            guard Date() >= nextHeartbeat, let key = storedKey,
                  storedSessionVersion(for: normalized(key)) != nil else { continue }
            await heartbeat()
            nextHeartbeat = Date().addingTimeInterval(15)
        }
    }

    func restore() async {
        guard !explicitActivationInFlight else { return }

        let generation = beginValidation()
        guard let savedKey = storedKey, !savedKey.isEmpty else {
            guard generation == validationGeneration else { return }
            deauthorize()
            return
        }

        let normalizedKey = normalized(savedKey)
        guard let sessionVersion = storedSessionVersion(for: normalizedKey) else {
            guard generation == validationGeneration, !Task.isCancelled else { return }
            deauthorize()
            notice = "Enter your key to resume this saved session."
            return
        }

        let outcome = await validate(
            normalizedKey,
            sessionVersion: sessionVersion,
            claim: false
        )
        guard generation == validationGeneration, !Task.isCancelled else { return }
        _ = apply(outcome, key: normalizedKey, claim: false)
    }

    func activate(_ rawKey: String) async -> FirebaseKeyValidationResult {
        let normalizedKey = normalized(rawKey)
        guard !normalizedKey.isEmpty else {
            return .failure("Enter a key to continue.")
        }

        explicitActivationInFlight = true
        notice = nil
        let generation = beginValidation()
        defer { explicitActivationInFlight = false }

        let outcome = await validate(
            normalizedKey,
            sessionVersion: storedSessionVersion(for: normalizedKey),
            claim: true
        )
        guard generation == validationGeneration, !Task.isCancelled else {
            return .failure("Activation was superseded. Try again.")
        }
        return apply(outcome, key: normalizedKey, claim: true)
    }

    func selectMode(_ mode: FaxAuraMode) {
        selectedMode = mode
        UserDefaults.standard.set(mode.rawValue, forKey: modeStorage)
    }

    private func heartbeat() async {
        guard !explicitActivationInFlight else { return }
        guard let key = storedKey, !key.isEmpty,
              let sessionVersion = storedSessionVersion(for: normalized(key)) else {
            deauthorize()
            notice = "A saved session is required. Enter your key to continue."
            return
        }

        let normalizedKey = normalized(key)
        let generation = beginValidation()
        let outcome = await validate(
            normalizedKey,
            sessionVersion: sessionVersion,
            claim: false
        )
        guard generation == validationGeneration, !Task.isCancelled else { return }
        _ = apply(outcome, key: normalizedKey, claim: false)
    }

    private func apply(
        _ outcome: SupabaseValidationOutcome,
        key: String,
        claim: Bool
    ) -> FirebaseKeyValidationResult {
        switch outcome {
        case .active(let response):
            persistSession(key: key, response: response)
            isAuthorized = true
            notice = nil
            if claim {
                selectedMode = nil
            } else {
                selectedMode = storedMode
            }
            return .success("Session activated.")

        case .rejected(let response):
            let code = response.code.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
            let message = message(for: code)

            if code == "paused" {
                persistSession(key: key, response: response, preserveExpiration: true)
                deauthorize()
            } else if ["revoked", "invalid", "expired", "session_released", "device_mismatch"].contains(code) {
                clearCredentials()
            } else {
                deauthorize()
            }

            notice = message
            return .failure(message)

        case .transportFailure(let message):
            deauthorize()
            notice = message
            return .failure(message)
        }
    }

    private func validate(
        _ key: String,
        sessionVersion: Int?,
        claim: Bool
    ) async -> SupabaseValidationOutcome {
        let hash = SHA256.hash(data: Data(normalized(key).utf8))
            .map { String(format: "%02X", $0) }
            .joined()

        guard let url = URL(string: "\(supabaseURL)/rest/v1/rpc/aura_validate") else {
            return .transportFailure("Unable to prepare the license request.")
        }

        let sessionValue: Any
        if let sessionVersion {
            sessionValue = sessionVersion
        } else {
            sessionValue = NSNull()
        }
        let payload: [String: Any] = [
            "p_key_hash": hash,
            "p_device_id": deviceID,
            "p_device_model": deviceModel,
            "p_device_identifier": machineIdentifier,
            "p_ios_version": UIDevice.current.systemVersion,
            "p_session_version": sessionValue,
            "p_claim": claim
        ]

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.timeoutInterval = 20
        request.setValue(anonKey, forHTTPHeaderField: "apikey")
        request.setValue("Bearer \(anonKey)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("application/json", forHTTPHeaderField: "Accept")

        do {
            request.httpBody = try JSONSerialization.data(withJSONObject: payload, options: [])
            let (data, response) = try await URLSession.shared.data(for: request)
            guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
                return .transportFailure("Unable to reach the license server. Check your connection and try again.")
            }

            let validation = try JSONDecoder().decode(SupabaseAuraValidationResponse.self, from: data)
            let code = validation.code.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
            if validation.ok && code == "active" {
                return .active(validation)
            }
            return .rejected(validation)
        } catch is CancellationError {
            return .transportFailure("License verification was cancelled. Try again.")
        } catch {
            return .transportFailure("Unable to reach the license server. Check your connection and try again.")
        }
    }

    private func persistSession(
        key: String,
        response: SupabaseAuraValidationResponse,
        preserveExpiration: Bool = false
    ) {
        let defaults = UserDefaults.standard
        defaults.set(key, forKey: savedKeyStorage)
        defaults.removeObject(forKey: legacyKeyStorage)
        defaults.set(response.sessionVersion, forKey: sessionVersionStorage)
        persistExpiration(from: response, preserveExisting: preserveExpiration)
    }

    private func persistExpiration(
        from response: SupabaseAuraValidationResponse,
        preserveExisting: Bool
    ) {
        guard let expiresAt = response.expiresAt,
              let expiration = parseServerDate(expiresAt) else {
            if !preserveExisting {
                UserDefaults.standard.removeObject(forKey: expirationStorage)
            }
            return
        }

        let adjustedExpiration: Date
        if let serverNow = parseServerDate(response.serverNow) {
            let localClockSkew = Date().timeIntervalSince1970 - serverNow.timeIntervalSince1970
            adjustedExpiration = expiration.addingTimeInterval(localClockSkew)
        } else {
            adjustedExpiration = expiration
        }
        UserDefaults.standard.set(adjustedExpiration.timeIntervalSince1970, forKey: expirationStorage)
    }

    private func clearCredentials() {
        let defaults = UserDefaults.standard
        defaults.removeObject(forKey: savedKeyStorage)
        defaults.removeObject(forKey: legacyKeyStorage)
        defaults.removeObject(forKey: sessionVersionStorage)
        defaults.removeObject(forKey: expirationStorage)
        defaults.removeObject(forKey: modeStorage)
        deauthorize()
    }

    private func deauthorize() {
        selectedMode = nil
        isAuthorized = false
    }

    private func beginValidation() -> Int {
        validationGeneration += 1
        return validationGeneration
    }

    private var storedKey: String? {
        UserDefaults.standard.string(forKey: savedKeyStorage)
            ?? UserDefaults.standard.string(forKey: legacyKeyStorage)
    }

    private var storedMode: FaxAuraMode? {
        guard let rawValue = UserDefaults.standard.string(forKey: modeStorage) else { return nil }
        return FaxAuraMode(rawValue: rawValue)
    }

    private func storedSessionVersion(for key: String) -> Int? {
        guard let savedKey = storedKey, normalized(savedKey) == normalized(key) else { return nil }
        return UserDefaults.standard.object(forKey: sessionVersionStorage) as? Int
    }

    private var localExpirationHasPassed: Bool {
        guard let value = UserDefaults.standard.object(forKey: expirationStorage) as? NSNumber else {
            return false
        }
        return value.doubleValue <= Date().timeIntervalSince1970
    }

    private func normalized(_ key: String) -> String {
        key.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
    }

    private var deviceID: String {
        if let vendorID = UIDevice.current.identifierForVendor?.uuidString,
           !vendorID.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            return vendorID
        }
        let defaults = UserDefaults.standard
        if let fallback = defaults.string(forKey: fallbackDeviceIDStorage), !fallback.isEmpty {
            return fallback
        }
        let fallback = UUID().uuidString
        defaults.set(fallback, forKey: fallbackDeviceIDStorage)
        return fallback
    }

    private var deviceModel: String {
        let identifier = machineIdentifier
        let compactIdentifier = identifier.hasPrefix("iPhone")
            ? String(identifier.dropFirst("iPhone".count))
            : identifier
        if let commercialName = Self.iPhoneModels[identifier] ?? Self.iPhoneModels[compactIdentifier] {
            return commercialName
        }
        if UIDevice.current.userInterfaceIdiom == .phone {
            return "iPhone (\(identifier))"
        }
        return "\(UIDevice.current.model) (\(identifier))"
    }

    private var machineIdentifier: String {
        var systemInfo = utsname()
        uname(&systemInfo)
        return withUnsafeBytes(of: &systemInfo.machine) { rawBuffer in
            let bytes = rawBuffer.bindMemory(to: UInt8.self)
            let end = bytes.firstIndex(of: 0) ?? bytes.endIndex
            return String(decoding: bytes[..<end], as: UTF8.self)
        }
    }

    private func parseServerDate(_ value: String) -> Date? {
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        if let date = formatter.date(from: value) { return date }
        formatter.formatOptions = [.withInternetDateTime]
        return formatter.date(from: value)
    }

    private func message(for code: String) -> String {
        switch code {
        case "paused": return "Key paused. Your remaining time is frozen."
        case "revoked": return "This key has been revoked."
        case "expired": return "This key has expired."
        case "invalid": return "Invalid key."
        case "device_mismatch": return "This key is linked to another device."
        case "session_released": return "This session was released. Enter your key to claim a new session."
        case "session_required": return "A saved session is required. Enter your key to continue."
        default: return "Access was denied."
        }
    }

    private static let iPhoneModels: [String: String] = [
        "10,1": "iPhone 8", "10,4": "iPhone 8",
        "10,2": "iPhone 8 Plus", "10,5": "iPhone 8 Plus",
        "10,3": "iPhone X", "10,6": "iPhone X",
        "11,2": "iPhone XS", "11,4": "iPhone XS Max", "11,6": "iPhone XS Max",
        "11,8": "iPhone XR",
        "12,1": "iPhone 11", "12,3": "iPhone 11 Pro", "12,5": "iPhone 11 Pro Max",
        "13,1": "iPhone 12 mini", "13,2": "iPhone 12", "13,3": "iPhone 12 Pro", "13,4": "iPhone 12 Pro Max",
        "14,2": "iPhone 13 Pro", "14,3": "iPhone 13 Pro Max", "14,4": "iPhone 13 mini",
        "14,5": "iPhone 13", "14,6": "iPhone SE (3rd generation)",
        "14,7": "iPhone 14", "14,8": "iPhone 14 Plus",
        "15,2": "iPhone 14 Pro", "15,3": "iPhone 14 Pro Max",
        "15,4": "iPhone 15", "15,5": "iPhone 15 Plus",
        "16,1": "iPhone 15 Pro", "16,2": "iPhone 15 Pro Max",
        "17,1": "iPhone 16 Pro", "17,2": "iPhone 16 Pro Max", "17,3": "iPhone 16", "17,4": "iPhone 16 Plus", "17,5": "iPhone 16e",
        "18,1": "iPhone 17 Pro", "18,2": "iPhone 17 Pro Max", "18,3": "iPhone 17", "18,4": "iPhone Air", "18,5": "iPhone 17e",
        "19,2": "iPhone 18 Pro", "19,3": "iPhone 18 Pro Max", "19,4": "iPhone Duo", "19,7": "iPhone 18 Pro Max"
    ]
}

private struct SupabaseAuraValidationResponse: Decodable {
    let ok: Bool
    let code: String
    let expiresAt: String?
    let serverNow: String
    let sessionVersion: Int
    let remainingSeconds: Double?

    enum CodingKeys: String, CodingKey {
        case ok, code
        case expiresAt = "expires_at"
        case serverNow = "server_now"
        case sessionVersion = "session_version"
        case remainingSeconds = "remaining_seconds"
    }
}

private struct FirebaseAuraModeSelectionView: View {
    let onSelect: (FaxAuraMode) -> Void

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [Color.black, Color(white: 0.16), Color.black],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()

            Circle()
                .fill(Color.white.opacity(0.13))
                .frame(width: 300, height: 300)
                .blur(radius: 80)
                .offset(y: -180)

            VStack(spacing: 0) {
                HStack(spacing: 10) {
                    AppLogo(size: 34)
                    VStack(alignment: .leading, spacing: 3) {
                        Text("FAX AURA")
                            .font(.system(size: 16, weight: .black, design: .rounded))
                            .tracking(1.5)
                            .foregroundStyle(Color.white.opacity(0.95))
                        Text("PRIVATE ACCESS")
                            .font(.system(size: 10, weight: .bold, design: .monospaced))
                            .foregroundStyle(.secondary)
                    }
                    Spacer()
                    HStack(spacing: 6) {
                        Circle().fill(.white).frame(width: 7, height: 7).shadow(color: .white, radius: 4)
                        Text("ONLINE")
                            .font(.system(size: 10, weight: .black, design: .monospaced))
                            .foregroundStyle(.secondary)
                    }
                }
                .padding(.horizontal, 14)
                .padding(.vertical, 12)

                ZStack {
                    Color.black
                    Image("ActivityHeaderArt")
                        .resizable()
                        .aspectRatio(3.0, contentMode: .fit)
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                }
                    .frame(maxWidth: .infinity)
                    .frame(height: 132)
                    .clipShape(RoundedRectangle(cornerRadius: 19, style: .continuous))
                    .overlay(
                        RoundedRectangle(cornerRadius: 19, style: .continuous)
                            .stroke(Color.white.opacity(0.72), lineWidth: 1.2)
                    )
                    .shadow(color: .white.opacity(0.42), radius: 16)
                    .padding(.horizontal, 12)

                VStack(spacing: 20) {
                    HStack(spacing: 13) {
                        Image("FreeFireLogo")
                            .resizable()
                            .scaledToFill()
                             .frame(width: 52, height: 52)
                            .clipShape(RoundedRectangle(cornerRadius: 15, style: .continuous))
                            .overlay(RoundedRectangle(cornerRadius: 15, style: .continuous).stroke(Color.white.opacity(0.60), lineWidth: 1))
                            .shadow(color: .white.opacity(0.22), radius: 7)
                        VStack(alignment: .leading, spacing: 4) {
                            Text("FREE FIRE")
                                .font(.system(size: 18, weight: .black, design: .rounded))
                                .tracking(1.0)
                                .foregroundStyle(.white)
                            Text("NORMAL PROFILE")
                                .font(.system(size: 10, weight: .black, design: .monospaced))
                                .foregroundStyle(Color.white.opacity(0.95))
                        }
                        Spacer()
                        Text("STABLE")
                            .font(.system(size: 8, weight: .black, design: .monospaced))
                            .foregroundStyle(.white)
                            .padding(.horizontal, 8)
                            .frame(height: 23)
                            .background(Color.white.opacity(0.10), in: Capsule())
                            .overlay(Capsule().stroke(Color.white.opacity(0.35), lineWidth: 1))
                        Image(systemName: "checkmark.seal.fill")
                            .font(.system(size: 22, weight: .bold))
                            .foregroundStyle(.white)
                            .shadow(color: .white.opacity(0.45), radius: 6)
                    }
                    .padding(.horizontal, 18)
                    .frame(maxWidth: .infinity)
                     .frame(height: 72)
                    .background(
                        LinearGradient(colors: [Color.white.opacity(0.18), Color.white.opacity(0.06)], startPoint: .leading, endPoint: .trailing),
                        in: RoundedRectangle(cornerRadius: 14, style: .continuous)
                    )
                    .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(Color.white.opacity(0.68), lineWidth: 1.2))

                    Text("SELECT GAME MODE")
                        .font(.system(size: 11, weight: .black, design: .monospaced))
                        .tracking(1.2)
                        .foregroundStyle(.secondary)

                    modeButton(.normal)
                }
                .padding(.horizontal, 18)
                .padding(.top, 12)
                .padding(.bottom, 14)
            }
            .frame(maxWidth: 410)
            .background(
                LinearGradient(
                    colors: [Color.white.opacity(0.16), Color.white.opacity(0.08), Color.black.opacity(0.58)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                ),
                in: RoundedRectangle(cornerRadius: 22, style: .continuous)
            )
            .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous).stroke(Color.white.opacity(0.54), lineWidth: 1.0))
            .shadow(color: .white.opacity(0.32), radius: 26)
             .padding(10)
        }
    }

    private func modeButton(_ mode: FaxAuraMode) -> some View {
        Button { onSelect(mode) } label: {
            HStack(spacing: 15) {
                ZStack {
                    RoundedRectangle(cornerRadius: 14, style: .continuous)
                        .fill(Color.white.opacity(0.18))
                    Image(systemName: mode.icon)
                        .font(.system(size: 18, weight: .black))
                        .foregroundStyle(Color.white.opacity(0.95))
                }
                 .frame(width: 40, height: 40)
                VStack(alignment: .leading, spacing: 4) {
                    Text(mode.title)
                        .font(.system(size: 16, weight: .black, design: .rounded))
                        .foregroundStyle(.white)
                    Text(mode.subtitle)
                        .font(.subheadline)
                    Text("PROFILE READY / SAFE MODE")
                        .font(.system(size: 8, weight: .black, design: .monospaced))
                        .foregroundStyle(.secondary)
                        .foregroundStyle(.secondary)
                }
                Spacer()
                HStack(spacing: 5) {
                    Text("ENTER")
                        .font(.system(size: 8, weight: .black, design: .monospaced))
                    Image(systemName: "arrow.right")
                        .font(.system(size: 10, weight: .black))
                }
                .foregroundStyle(.white)
                .padding(.horizontal, 10)
                .frame(height: 28)
                .background(Color.white.opacity(0.82), in: Capsule())
            }
             .padding(.horizontal, 12)
            .frame(maxWidth: .infinity)
             .frame(height: 78)
            .background(
                LinearGradient(colors: [Color.white.opacity(0.19), Color.white.opacity(0.075)], startPoint: .leading, endPoint: .trailing),
                in: RoundedRectangle(cornerRadius: 14, style: .continuous)
            )
            .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(Color.white.opacity(0.72), lineWidth: 1.2))
            .shadow(color: .white.opacity(0.18), radius: 10, y: 3)
        }
        .buttonStyle(.plain)
    }
}

private struct FirebaseKeyActivationView: View {
    @State private var key = ""
    @State private var showKey = false
    @State private var message = ""
    @State private var isLoading = false
    @State private var activationTask: Task<Void, Never>?
    let sessionNotice: String?
    let onActivate: (String) async -> FirebaseKeyValidationResult

    var body: some View {
        ZStack {
            LinearGradient(colors: [Color.black, Color(white: 0.025), Color.black], startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()
            VStack(spacing: 14) {
                HStack(spacing: 10) {
                    AppLogo(size: 38)
                    VStack(alignment: .leading, spacing: 3) {
                        Text("FAX AURA").font(.system(size: 13, weight: .black, design: .rounded)).tracking(1.8).foregroundStyle(.white)
                        Text("PRIVATE CONTROL CENTER").font(.system(size: 8, weight: .bold, design: .monospaced)).tracking(0.7).foregroundStyle(.secondary)
                    }
                    Spacer()
                    HStack(spacing: 6) {
                        Circle().fill(.white).frame(width: 7, height: 7).shadow(color: .white, radius: 4)
                        Text("SYSTEM ONLINE").font(.system(size: 8, weight: .black, design: .monospaced)).foregroundStyle(.secondary)
                    }
                }
                 .padding(.horizontal, 14).padding(.vertical, 12)
                ZStack(alignment: .bottomLeading) {
                    ZStack {
                        Color.black
                        Image("ActivityHeaderArt")
                            .resizable()
                            .aspectRatio(3.0, contentMode: .fit)
                            .frame(maxWidth: .infinity, maxHeight: .infinity)
                    }
                    .frame(maxWidth: .infinity)
                    .frame(height: 120)
                    LinearGradient(colors: [Color.black.opacity(0.05), Color.black.opacity(0.92)], startPoint: .center, endPoint: .bottom)
                    VStack(alignment: .leading, spacing: 3) {
                        Text("FAX AURA").font(.system(size: 22, weight: .black, design: .rounded)).tracking(1.0)
                        Text("SECURE ACTIVATION PANEL").font(.system(size: 9, weight: .black, design: .monospaced)).tracking(0.8).foregroundStyle(.white)
                    }.foregroundStyle(.white) .padding(10)
                }
                 .frame(height: 120)
                .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 14, style: .continuous).stroke(Color.white.opacity(0.72), lineWidth: 1.2))
                .shadow(color: .white.opacity(0.42), radius: 16)
                .padding(.horizontal, 12)
                VStack(alignment: .leading, spacing: 13) {
                    HStack {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("WELCOME BACK").font(.system(size: 10, weight: .black, design: .monospaced)).tracking(1.4).foregroundStyle(.white)
                            Text("Enter your key").font(.system(size: 22, weight: .black, design: .rounded)).foregroundStyle(.white)
                        }
                        Spacer()
                        Image(systemName: "lock.shield.fill").font(.system(size: 20, weight: .bold)).foregroundStyle(.white.opacity(0.9)).shadow(color: .white.opacity(0.5), radius: 8)
                    }
                    Text("Unlock your private Fax Aura session.").font(.subheadline).foregroundStyle(.secondary)
                    HStack {
                        Text("ACCESS KEY").font(.system(size: 9, weight: .black, design: .monospaced)).tracking(1.1).foregroundStyle(.secondary)
                        Spacer()
                        Text("SECURE INPUT").font(.system(size: 8, weight: .black, design: .monospaced)).foregroundStyle(.white.opacity(0.85))
                    }
                    .padding(.top, 5)
                    HStack(spacing: 10) {
                        Image(systemName: "lock.fill").font(.system(size: 15, weight: .bold)).foregroundStyle(.white).frame(width: 24)
                        Group {
                            if showKey { TextField("Enter your key", text: $key) }
                            else { SecureField("Enter your key", text: $key) }
                        }
                        .textInputAutocapitalization(.characters).autocorrectionDisabled().foregroundStyle(.white)
                        Button { showKey.toggle() } label: { Image(systemName: showKey ? "eye.slash.fill" : "eye.fill").font(.system(size: 14, weight: .bold)).foregroundStyle(.secondary) }.buttonStyle(.plain)
                    }
                    .padding(.horizontal, 14) .frame(height: 46)
                    .background(LinearGradient(colors: [Color.white.opacity(0.12), Color.black.opacity(0.22)], startPoint: .topLeading, endPoint: .bottomTrailing), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 14, style: .continuous).stroke(Color.white.opacity(0.58), lineWidth: 1))
                    .shadow(color: .black.opacity(0.3), radius: 7, y: 3)
                    Button(action: activateKey) {
                        HStack {
                            if isLoading { ProgressView().tint(.white) }
                            Text(isLoading ? "CHECKING ACCESS..." : "INITIALIZE SESSION").font(.headline.weight(.black))
                            Spacer()
                            if !isLoading { Image(systemName: "arrow.right").font(.system(size: 14, weight: .bold)) }
                        }
                        .padding(.horizontal, 21).frame(maxWidth: .infinity) .frame(height: 56)
                        .background(Color.white.opacity(0.16), in: Capsule())
                        .overlay(Capsule().stroke(Color.white.opacity(0.88), lineWidth: 1.1))
                        .foregroundStyle(.white).shadow(color: .white.opacity(0.16), radius: 12, y: 4)
                    }
                    .buttonStyle(.plain)
                    .disabled(isLoading || key.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                    HStack(spacing: 8) {
                        Image(systemName: "shield.checkered")
                        Text("PROTECTED SESSION").font(.system(size: 9, weight: .black, design: .monospaced))
                        Spacer()
                        Text("FAX AURA").font(.system(size: 9, weight: .black, design: .monospaced)).foregroundStyle(.white.opacity(0.85))
                    }.foregroundStyle(.secondary).padding(.top, 5)
                    HStack(spacing: 6) {
                        Image(systemName: "crown.fill")
                            .font(.system(size: 9, weight: .bold))
                            .foregroundStyle(.white.opacity(0.85))
                        Text("PROJECT CREATED BY")
                            .font(.system(size: 8, weight: .bold, design: .monospaced))
                            .foregroundStyle(.secondary)
                        Text("SENSIAURA")
                            .font(.system(size: 9, weight: .black, design: .rounded))
                            .tracking(0.7)
                            .foregroundStyle(.white.opacity(0.95))
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.top, 2)
                    if let sessionNotice, !sessionNotice.isEmpty {
                        Text(sessionNotice).font(.caption.weight(.semibold)).foregroundStyle(.white).multilineTextAlignment(.center).frame(maxWidth: .infinity).padding(.vertical, 8).background(Color.white.opacity(0.10), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
                    } else if !message.isEmpty {
                        Text(message).font(.caption.weight(.semibold)).foregroundStyle(.white).multilineTextAlignment(.center).frame(maxWidth: .infinity).padding(.vertical, 8).background(Color.white.opacity(0.10), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
                    }
                } .padding(14)
            }
             .frame(maxWidth: 360)
            .background(LinearGradient(colors: [Color(white: 0.16), Color(white: 0.045)], startPoint: .topLeading, endPoint: .bottomTrailing), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous).stroke(Color.white.opacity(0.54), lineWidth: 1.0))
            .shadow(color: .white.opacity(0.30), radius: 24) .padding(10)
        }
        .onDisappear {
            activationTask?.cancel()
            activationTask = nil
            isLoading = false
        }
    }

    private func activateKey() {
        message = ""
        isLoading = true
        activationTask?.cancel()
        let submittedKey = key
        activationTask = Task {
            let result = await onActivate(submittedKey)
            guard !Task.isCancelled else { return }
            await MainActor.run {
                if case .failure(let error) = result { message = error }
                isLoading = false
                activationTask = nil
            }
        }
    }
}
